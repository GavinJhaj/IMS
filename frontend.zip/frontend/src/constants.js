// export const BASE_URL=import.meta.env.VITE_NODE_ENV==='development'?'http://localhost:5000':'';
export const BASE_URL='';
export const PRODUCTS_URL='/api/products'
export const USERS_URL='/api/users'
export const UPLOADS_URL='/api/upload'
export const CONTACT_URL='/api/contactus'
export const RESET_URL='/api/users/reset'


